import{a as t}from"../chunks/entry.Ddwf7RZP.js";export{t as start};
