import { c as create_ssr_component } from "../../chunks/ssr.js";
import "echarts";
const css = {
  code: "#map-container.svelte-igv7ov{width:100%;height:600px}",
  map: `{"version":3,"file":"+page.svelte","sources":["+page.svelte"],"sourcesContent":["<script>\\n  import { onMount } from \\"svelte\\";\\n  import * as echarts from 'echarts';\\n  import worldGeoJSON from \\"../lib/geomap.json\\"; // Import your GeoJSON file\\n\\n  let chart;\\n\\n  onMount(() => {\\n    chart = echarts.init(document.getElementById(\\"map-container\\"));\\n\\n    chart.setOption({\\n      series: [\\n        {\\n          type: \\"map\\",\\n          map: \\"world\\",\\n          data: [], // You can provide data here if needed\\n          emphasis: {\\n            label: {\\n              show: true,\\n            },\\n          },\\n        },\\n      ],\\n      geo: {\\n        map: \\"world\\",\\n        roam: true,\\n        silent: true,\\n      },\\n    });\\n\\n    chart.setMap(\\"world\\", worldGeoJSON); // Set the GeoJSON data\\n  });\\n\\n  // Cleanup when component is destroyed\\n  onDestroy(() => {\\n    if (chart) {\\n      chart.dispose();\\n    }\\n  });\\n<\/script>\\n\\n<div id=\\"map-container\\"></div>\\n\\n<style>\\n  #map-container {\\n    width: 100%;\\n    height: 600px;\\n  }\\n</style>\\n"],"names":[],"mappings":"AA4CE,4BAAe,CACb,KAAK,CAAE,IAAI,CACX,MAAM,CAAE,KACV"}`
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  onDestroy(() => {
  });
  $$result.css.add(css);
  return `<div id="map-container" class="svelte-igv7ov"></div>`;
});
export {
  Page as default
};
