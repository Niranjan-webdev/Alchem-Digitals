

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CXC4sljm.js","_app/immutable/chunks/scheduler.BvLojk_z.js","_app/immutable/chunks/index.3yJoD6ZP.js","_app/immutable/chunks/entry.Ddwf7RZP.js"];
export const stylesheets = [];
export const fonts = [];
