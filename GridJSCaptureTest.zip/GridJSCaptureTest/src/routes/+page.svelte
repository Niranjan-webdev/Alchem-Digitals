<script>
  import {Navbar, Footer} from "$lib"
</script>

<div>
  <Navbar/>
  <Footer/>
</div>